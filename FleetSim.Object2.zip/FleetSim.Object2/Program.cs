﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetSim.Objects.Class;
using FleetSim.Objects.Interface;


namespace FeetSim.Console2
{
    class Program
    {

        public static int RndNumber()
        {
            Random rnd = new Random();
            int randomMileage = rnd.Next(5000, 15000);
            return randomMileage;
        }

        private static void Main(string[] args)
        {
            List<Car> CarCollection = new List<Car>()
            {
                new Car
                { VIN = Guid.Empty,
                    Mileage = 0,
                    Color ="red",
                    LastServicedDate ="M/dd/yyyy h:mm: ss.fff.tt",
                    LastServicedMileage = 0,
                    Year = 1993,
                    Model ="Saturn" },

                new Car
                { VIN=Guid.Empty,
                    Mileage = 0,
                    Color ="white",
                    LastServicedDate = "M/dd/yyyy h:mm:ss.fff.tt",
                    LastServicedMileage =0,
                    Year =1983,
                    Model ="Citation"},

                new Car
                { VIN=Guid.Empty,
                    Mileage = 0,
                    Color = "blue",
                    LastServicedDate ="M/dd/yyyy h:mm:ss.fff.tt",
                    LastServicedMileage =0,
                    Year = 1981,
                    Model ="Ford"},

                new Car
                { VIN=Guid.Empty,
                    Mileage = 0,
                    Color = "red",
                    LastServicedDate ="M/dd/yyyy h:mm:ss.fff.tt",
                    LastServicedMileage =0,
                    Year =2017,
                    Model ="900"},

                new Car
                { VIN=Guid.Empty,
                    Mileage = 0,
                    Color = "white",
                    LastServicedDate ="M/dd/yyyy h:mm:ss.fff.tt",
                    LastServicedMileage =0,
                    Year =1951,
                    Model ="Mars"}
            };



        
                    
            for (int Counter = 1; Counter <= 10; Counter++)
            {


                //ICar test = new Car();
                //test.TuneUp();
                foreach (Car Auto in CarCollection)
                {
                    
         DateTime dateTime = DateTime.Now;

                    int whatMiles = RndNumber();
                   
                    Auto.Mileage += whatMiles;
                    
                    Auto.TuneUp(whatMiles);
           
                     
                    

                    //Console.WriteLine("The Car's VIN is: " + Auto.VIN +
                    //                "\nThe car's model name is: " + Auto.Model
                    //                + "\nThe model's year is: " + Auto.Year +
                    //                "\nThe Mileage is: " + rnd.Next(1, 200000) +
                    //                "\nThe Color is: " + Auto.Color +
                    //                "\nThe last time it was serviced was: " +
                    //                Auto.LastServicedMileage + dateTime.ToString("dd/MM/yyyy"));

                    //test.TuneUp();

                }
                   



            }
        
    }
    }
}
